const display = document.getElementById('display');

document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', () => {
        if (button.classList.contains('clear')) {
            display.value = '';
        } else if (button.classList.contains('equals')) {
            try {
                display.value = eval(display.value);
            } catch {
                display.value = 'Error';
            }
        } else {
            display.value += button.textContent;
        }
    });
});
